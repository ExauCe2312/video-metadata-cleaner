package app.videocleaner

import android.app.Activity
import android.content.ClipData
import android.content.ContentValues
import android.content.Intent
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.zip.CRC32

class MainActivity : Activity() {

    private lateinit var pickBtn: Button
    private lateinit var cleanBtn: Button
    private lateinit var shareBtn: Button
    private lateinit var openBtn: Button
    private lateinit var detailsBtn: Button
    private lateinit var fileCard: TextView
    private lateinit var privacyCard: TextView
    private lateinit var resultCard: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var report: TextView
    private val pickCode = 1001

    private var items: List<Item> = emptyList()
    private var outputs: List<Uri> = emptyList()

    // ------------------------------------------------------------------
    // Données
    // ------------------------------------------------------------------

    private class Summary {
        var name: String? = null
        var container: String? = null
        var size: Long = -1
        var durationMs: Long = -1
        var rotation: String? = null
        var vMime: String? = null
        var width: String? = null
        var height: String? = null
        var transfer: String? = null
        var fps: Double = -1.0
        var aMime: String? = null
        var aRate: String? = null
        var aChannels: String? = null
        var location: String? = null
        var creation: String? = null
        var paths: Set<String> = emptySet()
    }

    private class Fp {
        var count = 0L
        var bytes = 0L
        val crc = CRC32()
    }

    private class CleanResult(
        val uri: Uri,
        val name: String,
        val log: List<String>
    )

    private class Item(val uri: Uri, val summary: Summary)

    // ------------------------------------------------------------------
    // Interface
    // ------------------------------------------------------------------

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun card(initial: String): TextView {
        val tv = TextView(this)
        tv.text = initial
        tv.textSize = 15f
        tv.setPadding(dp(16), dp(14), dp(16), dp(14))
        val bg = GradientDrawable()
        bg.setColor(0xFFF1F3F4.toInt())
        bg.cornerRadius = dp(14).toFloat()
        tv.background = bg
        return tv
    }

    private fun addWithMargin(parent: LinearLayout, v: View) {
        val lp = LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        lp.topMargin = dp(12)
        parent.addView(v, lp)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val content = LinearLayout(this)
        content.orientation = LinearLayout.VERTICAL
        content.setPadding(dp(16), dp(16), dp(16), dp(24))

        val title = TextView(this)
        title.text = "Video Metadata Cleaner"
        title.textSize = 22f
        title.gravity = Gravity.CENTER

        pickBtn = Button(this)
        pickBtn.text = "Sélectionner des vidéos"
        pickBtn.setOnClickListener { pickVideo() }

        fileCard = card(
            "Aucune vidéo sélectionnée.\n\n" +
                "Choisis une ou plusieurs vidéos : elles sont analysées sans être modifiées. " +
                "« Nettoyer » crée des COPIES sans métadonnées personnelles, les originaux ne sont jamais touchés."
        )

        privacyCard = card("")
        privacyCard.visibility = View.GONE

        cleanBtn = Button(this)
        cleanBtn.text = "Nettoyer"
        cleanBtn.isEnabled = false
        cleanBtn.setOnClickListener { startClean() }

        progressBar = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal)
        progressBar.max = 100
        progressBar.visibility = View.GONE

        resultCard = card("")
        resultCard.visibility = View.GONE

        shareBtn = Button(this)
        shareBtn.text = "Partager la copie"
        shareBtn.isEnabled = false
        shareBtn.setOnClickListener { shareCopy() }

        openBtn = Button(this)
        openBtn.text = "Voir la copie"
        openBtn.isEnabled = false
        openBtn.setOnClickListener { openCopy() }

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(shareBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(openBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        detailsBtn = Button(this)
        detailsBtn.text = "Afficher les détails techniques"
        detailsBtn.visibility = View.GONE
        detailsBtn.setOnClickListener { toggleDetails() }

        report = TextView(this)
        report.typeface = Typeface.MONOSPACE
        report.textSize = 11f
        report.setTextIsSelectable(true)
        report.visibility = View.GONE

        content.addView(title)
        addWithMargin(content, pickBtn)
        addWithMargin(content, fileCard)
        addWithMargin(content, privacyCard)
        addWithMargin(content, cleanBtn)
        addWithMargin(content, progressBar)
        addWithMargin(content, resultCard)
        addWithMargin(content, row)
        addWithMargin(content, detailsBtn)
        addWithMargin(content, report)

        val scroll = ScrollView(this)
        scroll.addView(content)
        setContentView(scroll)
    }

    private fun setBusy(busy: Boolean) {
        pickBtn.isEnabled = !busy
        cleanBtn.isEnabled = !busy && items.isNotEmpty()
        shareBtn.isEnabled = !busy && outputs.isNotEmpty()
        openBtn.isEnabled = !busy && outputs.isNotEmpty()
    }

    private fun refreshLabels() {
        cleanBtn.text = if (items.size > 1) "Nettoyer les ${items.size} vidéos" else "Nettoyer"
        shareBtn.text = if (outputs.size > 1) "Partager les copies" else "Partager la copie"
        openBtn.text = if (outputs.size > 1) "Voir la 1re copie" else "Voir la copie"
    }

    private fun toggleDetails() {
        if (report.visibility == View.VISIBLE) {
            report.visibility = View.GONE
            detailsBtn.text = "Afficher les détails techniques"
        } else {
            report.visibility = View.VISIBLE
            detailsBtn.text = "Masquer les détails techniques"
        }
    }

    private fun fileText(s: Summary): String {
        val sb = StringBuilder()
        sb.append(s.name ?: "?").append('\n')
        sb.append(String.format(Locale.US, "%.1f Mo", s.size / 1_048_576.0))
        if (s.durationMs >= 0) sb.append(String.format(Locale.US, " · %.1f s", s.durationMs / 1000.0))
        sb.append('\n')
        if (s.width != null && s.height != null) sb.append(s.width).append(" x ").append(s.height)
        if (s.fps > 0) sb.append(String.format(Locale.US, " · %.0f images/s", s.fps))
        val vm = s.vMime
        if (vm != null) sb.append(" · ").append(codecName(vm))
        return sb.toString()
    }

    /** Résumé vie privée. Les coordonnées GPS ne sont volontairement PAS affichées ici (captures d'écran). */
    private fun privacyText(s: Summary): String {
        val sb = StringBuilder()
        sb.append(if (s.location != null) "⚠️ Localisation GPS présente\n" else "✅ Pas de localisation GPS\n")
        sb.append(if (s.creation != null) "⚠️ Date de création présente : ${s.creation}\n" else "✅ Pas de date de création\n")
        val maker = hasMakerBlocks(s)
        sb.append(if (maker) "⚠️ Blocs d'informations appareil présents (udta/meta)" else "✅ Pas de blocs d'informations appareil")
        return sb.toString()
    }

    private fun buildResult(name: String, after: Summary, verified: Boolean): String {
        val sb = StringBuilder()
        if (verified) {
            sb.append("✅ Copie propre créée : ").append(name).append('\n')
            sb.append("Dossier : Movies/VideoMetadataCleaner\n\n")
            sb.append("✅ Images et son identiques à l'original (vérifié par empreinte)\n")
        } else {
            sb.append("⚠️ Copie créée (").append(name).append(") mais la vérification a signalé une différence. ")
            sb.append("Ne la publie pas avant d'avoir lu les détails techniques.\n\n")
        }
        sb.append(privacyText(after))
        sb.append("\n\nL'original n'est pas modifié : publie la COPIE, pas l'original.")
        return sb.toString()
    }

    private fun hasMakerBlocks(s: Summary): Boolean =
        s.paths.any { it == "moov/udta" || it == "moov/meta" || it.endsWith("/uuid") }

    private fun isClean(s: Summary): Boolean =
        s.location == null && s.creation == null && !hasMakerBlocks(s)

    private fun filesText(list: List<Item>, failed: Int): String {
        if (list.size == 1 && failed == 0) return fileText(list[0].summary)
        val sb = StringBuilder()
        sb.append(list.size).append(" vidéos sélectionnées")
        if (failed > 0) sb.append(" (").append(failed).append(" illisible(s))")
        sb.append('\n')
        for ((i, item) in list.withIndex()) {
            val sm = item.summary
            sb.append('\n').append(i + 1).append(". ").append(sm.name ?: "?")
            sb.append(String.format(Locale.US, " · %.1f Mo", sm.size / 1_048_576.0))
            if (sm.durationMs >= 0) sb.append(String.format(Locale.US, " · %.1f s", sm.durationMs / 1000.0))
        }
        return sb.toString()
    }

    private fun countLine(label: String, k: Int, n: Int): String =
        if (k > 0) "⚠️ $label : $k vidéo(s) sur $n" else "✅ $label : aucune"

    private fun privacyCardText(list: List<Item>): String {
        if (list.size == 1) return "Avant nettoyage\n\n" + privacyText(list[0].summary)
        val n = list.size
        val gps = list.count { it.summary.location != null }
        val dates = list.count { it.summary.creation != null }
        val maker = list.count { hasMakerBlocks(it.summary) }
        return "Avant nettoyage ($n vidéos)\n\n" +
            countLine("Localisation GPS", gps, n) + "\n" +
            countLine("Date de création", dates, n) + "\n" +
            countLine("Informations appareil (udta/meta)", maker, n)
    }

    private fun pickVideo() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT)
        intent.addCategory(Intent.CATEGORY_OPENABLE)
        intent.type = "video/*"
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
        startActivityForResult(intent, pickCode)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickCode || resultCode != RESULT_OK) return
        val uris = ArrayList<Uri>()
        val clip = data?.clipData
        if (clip != null) {
            for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)
        } else {
            val single = data?.data
            if (single != null) uris.add(single)
        }
        if (uris.isEmpty()) return

        fileCard.text = "Analyse en cours..."
        privacyCard.visibility = View.GONE
        resultCard.visibility = View.GONE
        setBusy(true)
        Thread {
            val found = ArrayList<Item>()
            val details = StringBuilder()
            val errors = ArrayList<String>()
            for ((idx, uri) in uris.withIndex()) {
                runOnUiThread { fileCard.text = "Analyse ${idx + 1}/${uris.size}..." }
                try {
                    val res = analyze(uri)
                    found.add(Item(uri, res.second))
                    if (uris.size > 1) details.append("######## Vidéo ${idx + 1}/${uris.size} ########\n")
                    details.append(res.first).append('\n')
                } catch (e: Exception) {
                    errors.add("Vidéo ${idx + 1} : ${e.javaClass.simpleName} - ${e.message}")
                }
            }
            if (errors.isNotEmpty()) {
                details.append("\n== ERREURS D'ANALYSE ==\n")
                for (er in errors) details.append(er).append('\n')
            }
            val finalDetails = details.toString()
            val failedCount = errors.size
            runOnUiThread {
                report.text = finalDetails
                detailsBtn.visibility = View.VISIBLE
                if (found.isNotEmpty()) {
                    items = found
                    outputs = emptyList()
                    fileCard.text = filesText(found, failedCount)
                    privacyCard.text = privacyCardText(found)
                    privacyCard.visibility = View.VISIBLE
                } else {
                    fileCard.text = "L'analyse a échoué. Ouvre les détails techniques pour voir l'erreur."
                }
                refreshLabels()
                setBusy(false)
            }
        }.start()
    }

    private fun openCopy() {
        val uri = outputs.firstOrNull() ?: return
        try {
            val intent = Intent(Intent.ACTION_VIEW)
            intent.setDataAndType(uri, "video/mp4")
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(intent)
        } catch (e: Exception) {
            resultCard.text = "Impossible d'ouvrir la copie : ${e.message}"
            resultCard.visibility = View.VISIBLE
        }
    }

    private fun shareCopy() {
        val list = outputs
        if (list.isEmpty()) return
        try {
            val intent: Intent
            if (list.size == 1) {
                intent = Intent(Intent.ACTION_SEND)
                intent.putExtra(Intent.EXTRA_STREAM, list[0])
            } else {
                intent = Intent(Intent.ACTION_SEND_MULTIPLE)
                intent.putParcelableArrayListExtra(Intent.EXTRA_STREAM, ArrayList<Uri>(list))
            }
            intent.type = "video/mp4"
            val clip = ClipData.newRawUri("video", list[0])
            for (i in 1 until list.size) clip.addItem(ClipData.Item(list[i]))
            intent.clipData = clip
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(intent, "Partager la copie nettoyée"))
        } catch (e: Exception) {
            resultCard.text = "Impossible de partager : ${e.message}"
            resultCard.visibility = View.VISIBLE
        }
    }

    // ------------------------------------------------------------------
    // Nettoyage
    // ------------------------------------------------------------------

    private fun buildMultiResult(lines: List<String>, created: Int, total: Int, failures: Int): String {
        val sb = StringBuilder()
        sb.append(created).append("/").append(total).append(" copies créées dans Movies/VideoMetadataCleaner\n\n")
        sb.append(lines.joinToString("\n")).append("\n\n")
        if (failures == 0) {
            sb.append("✅ Vérifié pour chaque copie : images et son identiques, métadonnées neutralisées.")
        } else {
            sb.append("⚠️ Certaines copies demandent attention : voir les détails techniques.")
        }
        sb.append("\n\nLes originaux ne sont pas modifiés : publie les COPIES.")
        return sb.toString()
    }

    private fun startClean() {
        val list = items
        if (list.isEmpty()) return
        setBusy(true)
        resultCard.visibility = View.GONE
        progressBar.progress = 0
        progressBar.visibility = View.VISIBLE
        Thread {
            val t0 = System.currentTimeMillis()
            val details = StringBuilder()
            val lines = ArrayList<String>()
            val outs = ArrayList<Uri>()
            var singleResult = ""
            var failures = 0
            for ((idx, item) in list.withIndex()) {
                val label = "${idx + 1}/${list.size}"
                val shortName = item.summary.name ?: "vidéo ${idx + 1}"
                runOnUiThread {
                    progressBar.progress = 0
                    cleanBtn.text = "Copie $label..."
                }
                if (list.size > 1) details.append("######## Vidéo $label ########\n")
                try {
                    val res = scrub(item.uri, item.summary.size) { p ->
                        runOnUiThread { progressBar.progress = p }
                    }
                    runOnUiThread { cleanBtn.text = "Vérification $label..." }
                    val beforeFp = fingerprint(item.uri)
                    val afterFp = fingerprint(res.uri)
                    val afterAnalysis = analyze(res.uri)
                    val cmp = compare(item.summary, afterAnalysis.second, beforeFp, afterFp, res.log)
                    val clean = isClean(afterAnalysis.second)

                    details.append("== NETTOYAGE TERMINÉ ==\n")
                    details.append("Copie : Movies/VideoMetadataCleaner/").append(res.name).append("\n\n")
                    details.append(cmp.first)
                    details.append("\n== ANALYSE COMPLÈTE DE LA COPIE ==\n\n")
                    details.append(afterAnalysis.first)

                    outs.add(res.uri)
                    if (!cmp.second || !clean) failures++
                    if (list.size == 1) {
                        singleResult = buildResult(res.name, afterAnalysis.second, cmp.second)
                    } else {
                        lines.add((if (cmp.second && clean) "✅ " else "⚠️ ") + shortName + " → " + res.name)
                    }
                } catch (e: Exception) {
                    failures++
                    details.append("Échec du nettoyage : ${e.javaClass.simpleName} - ${e.message}\n")
                    if (list.size == 1) {
                        singleResult = "❌ Le nettoyage a échoué. Voir les détails techniques."
                    } else {
                        lines.add("❌ $shortName : échec")
                    }
                }
                details.append('\n')
            }
            val seconds = (System.currentTimeMillis() - t0) / 1000.0
            val finalDetails = String.format(Locale.US, "Durée totale du traitement : %.1f s\n\n", seconds) + details.toString()
            val finalResult = if (list.size == 1) singleResult else buildMultiResult(lines, outs.size, list.size, failures)
            val finalOuts: List<Uri> = outs
            runOnUiThread {
                report.text = finalDetails
                detailsBtn.visibility = View.VISIBLE
                progressBar.visibility = View.GONE
                resultCard.text = finalResult
                resultCard.visibility = View.VISIBLE
                if (finalOuts.isNotEmpty()) outputs = finalOuts
                refreshLabels()
                setBusy(false)
            }
        }.start()
    }

    private fun keyFor(map: Map<String, Fp>, mime: String, index: Int): String =
        if (map.containsKey(mime)) "$mime#$index" else mime

    /**
     * Copie le fichier tel quel, puis neutralise sur la copie les blocs de métadonnées
     * (remplacés par des blocs vides « free » de même taille) et remet les dates à zéro.
     * Les données vidéo/audio (mdat) ne sont jamais touchées.
     */
    private fun scrub(src: Uri, totalSize: Long, onProgress: (Int) -> Unit): CleanResult {
        val tmp = File(cacheDir, "vmc_tmp.mp4")
        if (tmp.exists()) tmp.delete()
        val log = ArrayList<String>()
        try {
            val input = contentResolver.openInputStream(src)
                ?: throw IllegalStateException("Impossible de lire la vidéo")
            input.use { ins ->
                tmp.outputStream().use { outs ->
                    val buf = ByteArray(1024 * 1024)
                    var copied = 0L
                    var lastPct = -1
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        outs.write(buf, 0, n)
                        copied += n
                        if (totalSize > 0) {
                            val pct = (copied * 100 / totalSize).toInt().coerceIn(0, 100)
                            if (pct != lastPct) {
                                lastPct = pct
                                onProgress(pct)
                            }
                        }
                    }
                }
            }
            RandomAccessFile(tmp, "rw").use { raf ->
                Mp4Scrub(raf.channel, log).run()
            }
        } catch (e: Exception) {
            tmp.delete()
            throw e
        }

        val name = "cleaned_" + UUID.randomUUID().toString().substring(0, 8) + ".mp4"
        val uri = saveToMovies(tmp, name)
        tmp.delete()
        return CleanResult(uri, name, log)
    }

    private fun saveToMovies(tmp: File, displayName: String): Uri {
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/VideoMetadataCleaner")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val uri = contentResolver.insert(collection, values)
                ?: throw IllegalStateException("MediaStore a refusé de créer le fichier")
            val out = contentResolver.openOutputStream(uri)
                ?: throw IllegalStateException("Impossible d'écrire dans MediaStore")
            out.use { o -> tmp.inputStream().use { it.copyTo(o) } }
            val done = ContentValues()
            done.put(MediaStore.Video.Media.IS_PENDING, 0)
            contentResolver.update(uri, done, null, null)
            return uri
        } else {
            val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES)
                ?: throw IllegalStateException("Stockage externe indisponible")
            dir.mkdirs()
            val dest = File(dir, displayName)
            tmp.copyTo(dest, true)
            return Uri.fromFile(dest)
        }
    }

    /** Empreinte (nombre, taille, CRC32) des données compressées de chaque piste audio/vidéo. */
    private fun fingerprint(uri: Uri): Map<String, Fp> {
        val ex = MediaExtractor()
        val fps = LinkedHashMap<String, Fp>()
        try {
            ex.setDataSource(this, uri, null)
            val fpOf = HashMap<Int, Fp>()
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                    val fp = Fp()
                    fps[keyFor(fps, mime, i)] = fp
                    fpOf[i] = fp
                    ex.selectTrack(i)
                }
            }
            var buf = ByteBuffer.allocate(2 * 1024 * 1024)
            while (true) {
                val size = ex.sampleSize
                if (size > buf.capacity()) buf = ByteBuffer.allocate((size + size / 2).toInt())
                val n = ex.readSampleData(buf, 0)
                if (n < 0) break
                val fp = fpOf[ex.sampleTrackIndex]
                if (fp != null) {
                    fp.count++
                    fp.bytes += n
                    fp.crc.update(buf.array(), 0, n)
                }
                if (!ex.advance()) break
            }
        } finally {
            ex.release()
        }
        return fps
    }

    private fun mark(ok: Boolean): String = if (ok) "✓" else "✗"

    private fun compare(
        b: Summary,
        a: Summary,
        bf: Map<String, Fp>,
        af: Map<String, Fp>,
        log: List<String>
    ): Pair<String, Boolean> {
        val sb = StringBuilder()
        sb.append("== COMPARAISON AVANT → APRÈS ==\n")
        var allOk = bf.isNotEmpty()

        fun cmp(label: String, x: String?, y: String?) {
            if (x != y) allOk = false
            sb.append(mark(x == y)).append(' ').append(label).append(" : ")
                .append(x ?: "-").append(" → ").append(y ?: "-").append('\n')
        }

        cmp("Conteneur", b.container, a.container)
        cmp("Résolution", "${b.width} x ${b.height}", "${a.width} x ${a.height}")
        cmp("Codec vidéo", b.vMime, a.vMime)
        val fpsOk = b.fps > 0 && a.fps > 0 && Math.abs(b.fps - a.fps) < 0.05
        if (!fpsOk) allOk = false
        sb.append(mark(fpsOk)).append(" Images/s (mesuré) : ")
            .append(String.format(Locale.US, "%.2f → %.2f", b.fps, a.fps)).append('\n')
        cmp("Rotation", b.rotation, a.rotation)
        cmp("Transfert couleur (HDR/SDR)", b.transfer, a.transfer)
        cmp("Codec audio", b.aMime, a.aMime)
        cmp("Audio (Hz)", b.aRate, a.aRate)
        cmp("Audio (canaux)", b.aChannels, a.aChannels)
        val durOk = b.durationMs >= 0 && a.durationMs >= 0 && Math.abs(b.durationMs - a.durationMs) <= 100
        if (!durOk) allOk = false
        sb.append(mark(durOk)).append(" Durée : ").append(b.durationMs).append(" ms → ")
            .append(a.durationMs).append(" ms\n")
        sb.append("• Taille : ").append(String.format(Locale.US, "%.1f Mo → %.1f Mo", b.size / 1_048_576.0, a.size / 1_048_576.0)).append('\n')

        sb.append("\nDonnées compressées (empreinte CRC32) :\n")
        for ((k, f) in bf) {
            val o = af[k]
            if (o == null) {
                allOk = false
                sb.append("✗ ").append(k).append(" : absent de la copie\n")
            } else {
                val same = f.count == o.count && f.bytes == o.bytes && f.crc.value == o.crc.value
                if (!same) allOk = false
                sb.append(mark(same)).append(' ').append(k).append(" : ")
                    .append(if (same) "identique" else "DIFFÉRENT").append(" (")
                    .append(f.count).append(" échantillons, ").append(f.bytes).append(" octets, ")
                    .append(String.format(Locale.US, "%08x", f.crc.value))
                if (!same) {
                    sb.append(" → ").append(o.count).append(" échantillons, ").append(o.bytes)
                        .append(" octets, ").append(String.format(Locale.US, "%08x", o.crc.value))
                }
                sb.append(")\n")
            }
        }

        sb.append("\nMétadonnées :\n")
        sb.append("• Localisation : ").append(b.location ?: "aucune").append(" → ").append(a.location ?: "aucune").append('\n')
        sb.append("• Date de création : ").append(b.creation ?: "aucune").append(" → ").append(a.creation ?: "aucune").append('\n')
        val removed = b.paths.filter { !a.paths.contains(it) }
        val added = a.paths.filter { !b.paths.contains(it) }
        sb.append("• Blocs retirés : ").append(if (removed.isEmpty()) "aucun" else removed.joinToString(", ")).append('\n')
        sb.append("• Blocs ajoutés : ").append(if (added.isEmpty()) "aucun" else added.joinToString(", ")).append('\n')
        if (log.isNotEmpty()) {
            sb.append("\nNeutralisé dans la copie :\n")
            for (l in log) sb.append("• ").append(l).append('\n')
        } else {
            sb.append("\nRien à neutraliser : aucun bloc de métadonnées trouvé.\n")
        }
        return Pair(sb.toString(), allOk)
    }

    // ------------------------------------------------------------------
    // Analyse
    // ------------------------------------------------------------------

    private fun analyze(uri: Uri): Pair<String, Summary> {
        val sb = StringBuilder()
        val s = Summary()
        var locationFound: String? = null

        // 1. Fichier
        var name: String? = null
        var size = -1L
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si = c.getColumnIndex(OpenableColumns.SIZE)
                if (ni >= 0) name = c.getString(ni)
                if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
            }
        }
        s.size = size
        s.name = name
        sb.append("== FICHIER ==\n")
        sb.append("Nom : ").append(name ?: "?").append('\n')
        sb.append("Taille : ").append(formatSize(size)).append('\n')

        // 2. Infos générales
        sb.append("\n== INFOS GÉNÉRALES ==\n")
        val mmr = MediaMetadataRetriever()
        try {
            mmr.setDataSource(this, uri)
            fun g(key: Int): String? = mmr.extractMetadata(key)

            s.container = g(MediaMetadataRetriever.METADATA_KEY_MIMETYPE)
            line(sb, "Conteneur", s.container)
            val dur = g(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            if (dur != null) s.durationMs = dur
            line(sb, "Durée", dur?.let { String.format(Locale.US, "%.1f s", it / 1000.0) })
            val br = g(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toLongOrNull()
            line(sb, "Débit global", br?.let { String.format(Locale.US, "%.2f Mb/s", it / 1_000_000.0) })
            s.rotation = g(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
            line(sb, "Rotation", s.rotation?.let { "$it°" })
            line(sb, "Date (tag)", g(MediaMetadataRetriever.METADATA_KEY_DATE))
            locationFound = g(MediaMetadataRetriever.METADATA_KEY_LOCATION)

            sb.append("\n== TAGS PERSONNELS ==\n")
            line(sb, "Localisation", locationFound ?: "aucune")
            line(sb, "Titre", g(MediaMetadataRetriever.METADATA_KEY_TITLE))
            line(sb, "Auteur", g(MediaMetadataRetriever.METADATA_KEY_AUTHOR))
            line(sb, "Artiste", g(MediaMetadataRetriever.METADATA_KEY_ARTIST))
            line(sb, "Album", g(MediaMetadataRetriever.METADATA_KEY_ALBUM))
            line(sb, "Compositeur", g(MediaMetadataRetriever.METADATA_KEY_COMPOSER))
            line(sb, "Writer", g(MediaMetadataRetriever.METADATA_KEY_WRITER))
        } catch (e: Exception) {
            sb.append("Lecture impossible : ").append(e.message).append('\n')
        } finally {
            mmr.release()
        }

        // 3. Pistes
        sb.append("\n== PISTES ==\n")
        val ex = MediaExtractor()
        try {
            ex.setDataSource(this, uri, null)
            var videoIndex = -1
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: "?"
                sb.append("Piste ").append(i).append(" : ").append(codecName(mime)).append('\n')
                sb.append("  mime : ").append(mime).append('\n')
                if (mime.startsWith("video/")) {
                    if (videoIndex < 0) {
                        videoIndex = i
                        s.vMime = mime
                        s.width = num(f, MediaFormat.KEY_WIDTH)
                        s.height = num(f, MediaFormat.KEY_HEIGHT)
                        s.transfer = num(f, MediaFormat.KEY_COLOR_TRANSFER)?.let { transferName(it) }
                    }
                    val w = num(f, MediaFormat.KEY_WIDTH)
                    val h = num(f, MediaFormat.KEY_HEIGHT)
                    line(sb, "  résolution", if (w != null && h != null) "$w x $h" else null)
                    line(sb, "  fps (tag)", num(f, MediaFormat.KEY_FRAME_RATE))
                    line(sb, "  débit vidéo", num(f, MediaFormat.KEY_BIT_RATE)?.let { "$it b/s" })
                    line(sb, "  rotation", num(f, MediaFormat.KEY_ROTATION))
                    line(sb, "  transfert couleur", num(f, MediaFormat.KEY_COLOR_TRANSFER)?.let { transferName(it) })
                    line(sb, "  standard couleur", num(f, MediaFormat.KEY_COLOR_STANDARD))
                } else if (mime.startsWith("audio/")) {
                    if (s.aMime == null) {
                        s.aMime = mime
                        s.aRate = num(f, MediaFormat.KEY_SAMPLE_RATE)
                        s.aChannels = num(f, MediaFormat.KEY_CHANNEL_COUNT)
                    }
                    line(sb, "  échantillonnage", num(f, MediaFormat.KEY_SAMPLE_RATE)?.let { "$it Hz" })
                    line(sb, "  canaux", num(f, MediaFormat.KEY_CHANNEL_COUNT))
                    line(sb, "  débit audio", num(f, MediaFormat.KEY_BIT_RATE)?.let { "$it b/s" })
                    line(sb, "  langue", if (f.containsKey(MediaFormat.KEY_LANGUAGE)) f.getString(MediaFormat.KEY_LANGUAGE) else null)
                }
            }
            if (videoIndex >= 0) {
                ex.selectTrack(videoIndex)
                var count = 0
                var minT = Long.MAX_VALUE
                var maxT = Long.MIN_VALUE
                while (count < 300) {
                    val t = ex.sampleTime
                    if (t < 0) break
                    if (t < minT) minT = t
                    if (t > maxT) maxT = t
                    count++
                    if (!ex.advance()) break
                }
                if (count > 1 && maxT > minT) {
                    val fps = (count - 1) * 1_000_000.0 / (maxT - minT)
                    s.fps = fps
                    sb.append("fps estimé (").append(count).append(" premières images) : ")
                        .append(String.format(Locale.US, "%.2f", fps)).append('\n')
                }
            }
        } catch (e: Exception) {
            sb.append("Lecture impossible : ").append(e.message).append('\n')
        } finally {
            ex.release()
        }

        // 4. Structure MP4
        sb.append("\n== STRUCTURE DU FICHIER (MP4) ==\n")
        try {
            val pfd = contentResolver.openFileDescriptor(uri, "r")
            if (pfd == null) {
                sb.append("Fichier inaccessible.\n")
            } else {
                ParcelFileDescriptor.AutoCloseInputStream(pfd).use { stream ->
                    val ch = stream.channel
                    val total = ch.size()
                    val scan = Mp4Scan(ch, sb)
                    val stoppedAt = scan.walk(0L, total, 0, "")
                    if (stoppedAt < total) {
                        sb.append("\n⚠ Zone non reconnue à partir de l'octet ")
                            .append(stoppedAt).append(" (")
                            .append(total - stoppedAt).append(" octets)\n")
                    }
                    if (scan.location != null) locationFound = locationFound ?: scan.location
                    s.creation = scan.creation
                    s.paths = scan.paths
                }
            }
        } catch (e: Exception) {
            sb.append("Analyse de structure impossible : ").append(e.message).append('\n')
        }
        s.location = locationFound

        // 5. Résumé
        sb.append("\n== RÉSUMÉ VIE PRIVÉE ==\n")
        sb.append(if (locationFound != null) "⚠ Localisation GPS présente : $locationFound\n" else "✓ Pas de localisation détectée\n")
        sb.append(if (s.creation != null) "⚠ Date de création dans le fichier : ${s.creation}\n" else "✓ Pas de date de création détectée\n")
        sb.append("Cette liste n'est pas exhaustive : voir la structure ci-dessus.\n")

        return Pair(sb.toString(), s)
    }

    // ------------------------------------------------------------------
    // Utilitaires d'affichage
    // ------------------------------------------------------------------

    private fun line(sb: StringBuilder, label: String, value: String?) {
        if (value != null) sb.append(label).append(" : ").append(value).append('\n')
    }

    private fun num(f: MediaFormat, key: String): String? {
        if (!f.containsKey(key)) return null
        return try {
            f.getInteger(key).toString()
        } catch (e: Exception) {
            try {
                f.getFloat(key).toString()
            } catch (e2: Exception) {
                null
            }
        }
    }

    private fun formatSize(bytes: Long): String {
        if (bytes < 0) return "?"
        return String.format(Locale.US, "%.1f Mo (%d octets)", bytes / 1_048_576.0, bytes)
    }

    private fun codecName(mime: String): String = when (mime) {
        "video/avc" -> "Vidéo H.264 (AVC)"
        "video/hevc" -> "Vidéo H.265 (HEVC)"
        "video/x-vnd.on2.vp9" -> "Vidéo VP9"
        "video/av01" -> "Vidéo AV1"
        "audio/mp4a-latm" -> "Audio AAC"
        "audio/opus" -> "Audio Opus"
        "audio/ac3" -> "Audio AC-3"
        else -> mime
    }

    private fun transferName(v: String): String = when (v) {
        "1" -> "linéaire"
        "3" -> "SDR"
        "6" -> "PQ (HDR10)"
        "7" -> "HLG (HDR)"
        else -> v
    }

    // ------------------------------------------------------------------
    // Lecteur de boîtes MP4 (lecture seule)
    // ------------------------------------------------------------------

    private class Mp4Scan(private val ch: FileChannel, private val sb: StringBuilder) {
        var location: String? = null
        var creation: String? = null
        val paths = LinkedHashSet<String>()

        private class Hdr(val type: String, val size: Long, val headerSize: Int)

        private val containers = setOf("moov", "trak", "mdia", "minf", "udta", "edts", "dinf")

        fun walk(start: Long, end: Long, depth: Int, parentPath: String): Long {
            var pos = start
            var count = 0
            val parentType = parentPath.substringAfterLast('/')
            while (pos < end && count < 300) {
                val h = readHeader(pos, end) ?: break
                val path = if (parentPath.isEmpty()) h.type else parentPath + "/" + h.type
                paths.add(path)

                sb.append("  ".repeat(depth)).append(h.type).append(" (").append(h.size).append(" o)")
                when (h.type) {
                    "mvhd" -> readMvhd(pos + h.headerSize)
                    "\u00a9xyz" -> readLocation(pos + h.headerSize, h.size - h.headerSize)
                    "ftyp" -> readBrand(pos + h.headerSize)
                }
                sb.append('\n')

                if (h.type in containers) {
                    walk(pos + h.headerSize, pos + h.size, depth + 1, path)
                } else if (h.type == "meta") {
                    walkMeta(pos + h.headerSize, pos + h.size, depth + 1, path)
                } else if (parentType == "udta" || parentType == "meta") {
                    dump(pos + h.headerSize, h.size - h.headerSize, depth + 1)
                }
                pos += h.size
                count++
            }
            return pos
        }

        /** 'meta' existe avec ou sans l'en-tête version/flags de 4 octets : on essaie les deux. */
        private fun walkMeta(payloadStart: Long, payloadEnd: Long, depth: Int, path: String) {
            for (skip in intArrayOf(4, 0)) {
                val first = readHeader(payloadStart + skip, payloadEnd)
                if (first != null && first.size >= 8 && payloadStart + skip + first.size <= payloadEnd) {
                    walk(payloadStart + skip, payloadEnd, depth, path)
                    return
                }
            }
            dump(payloadStart, payloadEnd - payloadStart, depth)
        }

        private fun readHeader(pos: Long, end: Long): Hdr? {
            if (pos + 8 > end) return null
            val header = ByteBuffer.allocate(16)
            val n = ch.read(header, pos)
            if (n < 8) return null
            header.flip()
            var size = header.int.toLong() and 0xFFFFFFFFL
            val typeBytes = ByteArray(4)
            header.get(typeBytes)
            if (!printable(typeBytes)) return null
            val type = String(typeBytes, Charsets.ISO_8859_1)
            var headerSize = 8
            if (size == 1L) {
                if (n < 16) return null
                size = header.long
                headerSize = 16
            } else if (size == 0L) {
                size = end - pos
            }
            if (size < headerSize) return null
            if (pos + size > end) size = end - pos
            return Hdr(type, size, headerSize)
        }

        private fun printable(b: ByteArray): Boolean {
            for (x in b) {
                val v = x.toInt() and 0xFF
                if (v < 0x20 || v in 0x7F..0xA8) return false
            }
            return true
        }

        private fun dump(pos: Long, len: Long, depth: Int) {
            val n = minOf(len, 96L).toInt()
            if (n <= 0) return
            val b = ByteBuffer.allocate(n)
            val r = ch.read(b, pos)
            if (r <= 0) return
            val arr = b.array()
            val indent = "  ".repeat(depth)
            val hex = StringBuilder()
            for (i in 0 until minOf(r, 16)) hex.append(String.format("%02x ", arr[i].toInt() and 0xFF))
            val txt = StringBuilder()
            for (i in 0 until r) {
                val v = arr[i].toInt() and 0xFF
                txt.append(if (v in 0x20..0x7E) v.toChar() else '.')
            }
            sb.append(indent).append("hex: ").append(hex.toString().trim()).append('\n')
            sb.append(indent).append("txt: ").append(txt).append('\n')
        }

        private fun readBrand(pos: Long) {
            val b = ByteBuffer.allocate(4)
            if (ch.read(b, pos) == 4) {
                sb.append(" → marque ").append(String(b.array(), Charsets.ISO_8859_1))
            }
        }

        private fun readMvhd(pos: Long) {
            val b = ByteBuffer.allocate(12)
            if (ch.read(b, pos) < 12) return
            b.flip()
            val versionFlags = b.int
            val version = (versionFlags shr 24) and 0xFF
            val seconds: Long = if (version == 1) {
                val b8 = ByteBuffer.allocate(8)
                if (ch.read(b8, pos + 4) < 8) return
                b8.flip()
                b8.long
            } else {
                b.int.toLong() and 0xFFFFFFFFL
            }
            if (seconds == 0L) {
                sb.append(" → date de création non définie")
            } else {
                val epochMs = (seconds - 2082844800L) * 1000L
                val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.US)
                fmt.timeZone = TimeZone.getTimeZone("UTC")
                creation = fmt.format(Date(epochMs))
                sb.append(" → créé le ").append(creation)
            }
        }

        private fun readLocation(pos: Long, payload: Long) {
            val len = minOf(payload, 64L).toInt()
            if (len <= 4) return
            val b = ByteBuffer.allocate(len)
            if (ch.read(b, pos) < len) return
            val text = String(b.array(), 4, len - 4, Charsets.ISO_8859_1).trim()
            location = text
            sb.append(" → localisation : ").append(text)
        }
    }

    // ------------------------------------------------------------------
    // Neutralisation des métadonnées (écriture sur la COPIE uniquement)
    // ------------------------------------------------------------------

    private class Mp4Scrub(private val ch: FileChannel, private val log: MutableList<String>) {

        private class Hdr(val type: String, val size: Long, val headerSize: Int)

        fun run() {
            walk(0L, ch.size(), "")
        }

        private fun walk(start: Long, end: Long, path: String) {
            var pos = start
            var count = 0
            while (pos < end && count < 300) {
                val h = readHeader(pos, end) ?: break
                val here = if (path.isEmpty()) h.type else path + "/" + h.type
                val inner = pos + h.headerSize
                val innerEnd = pos + h.size
                when (path) {
                    "" -> when (h.type) {
                        "moov" -> walk(inner, innerEnd, here)
                        "uuid", "meta", "udta", "XMP_" -> makeFree(pos, h, here)
                    }
                    "moov" -> when (h.type) {
                        "udta", "meta", "uuid" -> makeFree(pos, h, here)
                        "mvhd" -> zeroTimes(pos, h, here)
                        "trak" -> walk(inner, innerEnd, here)
                    }
                    "moov/trak" -> when (h.type) {
                        "udta", "meta", "uuid" -> makeFree(pos, h, here)
                        "tkhd" -> zeroTimes(pos, h, here)
                        "mdia" -> walk(inner, innerEnd, here)
                    }
                    "moov/trak/mdia" -> when (h.type) {
                        "mdhd" -> zeroTimes(pos, h, here)
                        "udta", "meta", "uuid" -> makeFree(pos, h, here)
                    }
                    else -> {}
                }
                pos += h.size
                count++
            }
        }

        private fun makeFree(pos: Long, h: Hdr, label: String) {
            writeFully(ByteBuffer.wrap("free".toByteArray(Charsets.ISO_8859_1)), pos + 4)
            var p = pos + h.headerSize
            val end = pos + h.size
            val zeros = ByteArray(65536)
            while (p < end) {
                val n = minOf(zeros.size.toLong(), end - p).toInt()
                writeFully(ByteBuffer.wrap(zeros, 0, n), p)
                p += n
            }
            log.add("$label (${h.size} o) → remplacé par un bloc vide")
        }

        private fun zeroTimes(pos: Long, h: Hdr, label: String) {
            val vb = ByteBuffer.allocate(1)
            if (ch.read(vb, pos + h.headerSize) < 1) return
            val version = vb.get(0).toInt()
            val len = if (version == 1) 16 else 8
            if (h.size < h.headerSize + 4 + len) return
            writeFully(ByteBuffer.wrap(ByteArray(len)), pos + h.headerSize + 4)
            log.add("$label : dates de création/modification remises à zéro")
        }

        private fun writeFully(bb: ByteBuffer, position: Long) {
            var p = position
            while (bb.hasRemaining()) {
                p += ch.write(bb, p)
            }
        }

        private fun readHeader(pos: Long, end: Long): Hdr? {
            if (pos + 8 > end) return null
            val header = ByteBuffer.allocate(16)
            val n = ch.read(header, pos)
            if (n < 8) return null
            header.flip()
            var size = header.int.toLong() and 0xFFFFFFFFL
            val typeBytes = ByteArray(4)
            header.get(typeBytes)
            for (x in typeBytes) {
                val v = x.toInt() and 0xFF
                if (v < 0x20 || v in 0x7F..0xA8) return null
            }
            val type = String(typeBytes, Charsets.ISO_8859_1)
            var headerSize = 8
            if (size == 1L) {
                if (n < 16) return null
                size = header.long
                headerSize = 16
            } else if (size == 0L) {
                size = end - pos
            }
            if (size < headerSize) return null
            if (pos + size > end) size = end - pos
            return Hdr(type, size, headerSize)
        }
    }
}
