package app.videocleaner

import android.app.Activity
import android.content.ContentValues
import android.content.Intent
import android.graphics.Typeface
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.zip.CRC32

class MainActivity : Activity() {

    private lateinit var report: TextView
    private lateinit var pickBtn: Button
    private lateinit var cleanBtn: Button
    private lateinit var openBtn: Button
    private val pickCode = 1001

    private var selectedUri: Uri? = null
    private var beforeSummary: Summary? = null
    private var lastOutput: Uri? = null

    // ------------------------------------------------------------------
    // Données
    // ------------------------------------------------------------------

    private class Summary {
        var container: String? = null
        var size: Long = -1
        var durationMs: Long = -1
        var rotation: String? = null
        var vMime: String? = null
        var width: String? = null
        var height: String? = null
        var transfer: String? = null
        var fps: Double = -1.0
        var aMime: String? = null
        var aRate: String? = null
        var aChannels: String? = null
        var location: String? = null
        var creation: String? = null
        var paths: Set<String> = emptySet()
    }

    private class Fp {
        var count = 0L
        var bytes = 0L
        val crc = CRC32()
    }

    private class CleanResult(
        val uri: Uri,
        val name: String,
        val log: List<String>
    )

    // ------------------------------------------------------------------
    // Interface
    // ------------------------------------------------------------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        val title = TextView(this).apply {
            text = "Video Metadata Cleaner"
            textSize = 22f
            gravity = Gravity.CENTER
        }

        pickBtn = Button(this).apply {
            text = "Sélectionner une vidéo"
            setOnClickListener { pickVideo() }
        }

        cleanBtn = Button(this).apply {
            text = "Nettoyer"
            isEnabled = false
            setOnClickListener { startClean() }
        }

        openBtn = Button(this).apply {
            text = "Ouvrir la copie"
            isEnabled = false
            setOnClickListener { openCopy() }
        }

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(cleanBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        row.addView(openBtn, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))

        report = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setTextIsSelectable(true)
            text = "Aucune vidéo sélectionnée.\n\n" +
                "1. Sélectionne une vidéo : elle est analysée (rien n'est modifié).\n" +
                "2. Appuie sur « Nettoyer » : une COPIE est créée dans Movies/VideoMetadataCleaner, " +
                "l'original n'est jamais touché. Les images et le son ne sont pas retouchés."
        }

        val scroll = ScrollView(this).apply { addView(report) }

        layout.addView(title)
        layout.addView(pickBtn)
        layout.addView(row)
        layout.addView(
            scroll,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        setContentView(layout)
    }

    private fun setBusy(busy: Boolean) {
        pickBtn.isEnabled = !busy
        cleanBtn.isEnabled = !busy && selectedUri != null
        openBtn.isEnabled = !busy && lastOutput != null
    }

    private fun pickVideo() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
        }
        startActivityForResult(intent, pickCode)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickCode || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        report.text = "Analyse en cours..."
        setBusy(true)
        Thread {
            var text: String
            var summary: Summary? = null
            try {
                val res = analyze(uri)
                text = res.first
                summary = res.second
            } catch (e: Exception) {
                text = "Erreur pendant l'analyse : ${e.javaClass.simpleName} - ${e.message}"
            }
            runOnUiThread {
                report.text = text
                if (summary != null) {
                    selectedUri = uri
                    beforeSummary = summary
                    lastOutput = null
                }
                setBusy(false)
            }
        }.start()
    }

    private fun openCopy() {
        val uri = lastOutput ?: return
        try {
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "video/mp4")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(intent)
        } catch (e: Exception) {
            report.text = "Impossible d'ouvrir la copie : ${e.message}"
        }
    }

    // ------------------------------------------------------------------
    // Nettoyage
    // ------------------------------------------------------------------

    private fun startClean() {
        val src = selectedUri ?: return
        val before = beforeSummary ?: return
        setBusy(true)
        report.text = "Copie en cours... 0 %"
        Thread {
            var text: String
            var output: Uri? = null
            try {
                val t0 = System.currentTimeMillis()
                val res = scrub(src, before.size) { p ->
                    runOnUiThread { report.text = "Copie en cours... $p %" }
                }
                runOnUiThread { report.text = "Vérification de la copie..." }
                val beforeFp = fingerprint(src)
                val afterFp = fingerprint(res.uri)
                val afterAnalysis = analyze(res.uri)
                val seconds = (System.currentTimeMillis() - t0) / 1000.0

                val sb = StringBuilder()
                sb.append("== NETTOYAGE TERMINÉ ==\n")
                sb.append("Copie : Movies/VideoMetadataCleaner/").append(res.name).append('\n')
                sb.append(String.format(Locale.US, "Durée du traitement : %.1f s\n\n", seconds))
                sb.append(compare(before, afterAnalysis.second, beforeFp, afterFp, res.log))
                sb.append("\n== ANALYSE COMPLÈTE DE LA COPIE ==\n\n")
                sb.append(afterAnalysis.first)
                text = sb.toString()
                output = res.uri
            } catch (e: Exception) {
                text = "Échec du nettoyage : ${e.javaClass.simpleName} - ${e.message}"
            }
            runOnUiThread {
                report.text = text
                if (output != null) lastOutput = output
                setBusy(false)
            }
        }.start()
    }

    private fun keyFor(map: Map<String, Fp>, mime: String, index: Int): String =
        if (map.containsKey(mime)) "$mime#$index" else mime

    /**
     * Copie le fichier tel quel, puis neutralise sur la copie les blocs de métadonnées
     * (remplacés par des blocs vides « free » de même taille) et remet les dates à zéro.
     * Les données vidéo/audio (mdat) ne sont jamais touchées.
     */
    private fun scrub(src: Uri, totalSize: Long, onProgress: (Int) -> Unit): CleanResult {
        val tmp = File(cacheDir, "vmc_tmp.mp4")
        if (tmp.exists()) tmp.delete()
        val log = ArrayList<String>()
        try {
            val input = contentResolver.openInputStream(src)
                ?: throw IllegalStateException("Impossible de lire la vidéo")
            input.use { ins ->
                tmp.outputStream().use { outs ->
                    val buf = ByteArray(1024 * 1024)
                    var copied = 0L
                    var lastPct = -1
                    while (true) {
                        val n = ins.read(buf)
                        if (n < 0) break
                        outs.write(buf, 0, n)
                        copied += n
                        if (totalSize > 0) {
                            val pct = (copied * 100 / totalSize).toInt().coerceIn(0, 100)
                            if (pct != lastPct) {
                                lastPct = pct
                                onProgress(pct)
                            }
                        }
                    }
                }
            }
            RandomAccessFile(tmp, "rw").use { raf ->
                Mp4Scrub(raf.channel, log).run()
            }
        } catch (e: Exception) {
            tmp.delete()
            throw e
        }

        val name = "cleaned_" + UUID.randomUUID().toString().substring(0, 8) + ".mp4"
        val uri = saveToMovies(tmp, name)
        tmp.delete()
        return CleanResult(uri, name, log)
    }

    private fun saveToMovies(tmp: File, displayName: String): Uri {
        if (Build.VERSION.SDK_INT >= 29) {
            val values = ContentValues().apply {
                put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
                put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/VideoMetadataCleaner")
                put(MediaStore.Video.Media.IS_PENDING, 1)
            }
            val collection = MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
            val uri = contentResolver.insert(collection, values)
                ?: throw IllegalStateException("MediaStore a refusé de créer le fichier")
            val out = contentResolver.openOutputStream(uri)
                ?: throw IllegalStateException("Impossible d'écrire dans MediaStore")
            out.use { o -> tmp.inputStream().use { it.copyTo(o) } }
            val done = ContentValues()
            done.put(MediaStore.Video.Media.IS_PENDING, 0)
            contentResolver.update(uri, done, null, null)
            return uri
        } else {
            val dir = getExternalFilesDir(Environment.DIRECTORY_MOVIES)
                ?: throw IllegalStateException("Stockage externe indisponible")
            dir.mkdirs()
            val dest = File(dir, displayName)
            tmp.copyTo(dest, true)
            return Uri.fromFile(dest)
        }
    }

    /** Empreinte (nombre, taille, CRC32) des données compressées de chaque piste audio/vidéo. */
    private fun fingerprint(uri: Uri): Map<String, Fp> {
        val ex = MediaExtractor()
        val fps = LinkedHashMap<String, Fp>()
        try {
            ex.setDataSource(this, uri, null)
            val fpOf = HashMap<Int, Fp>()
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: ""
                if (mime.startsWith("video/") || mime.startsWith("audio/")) {
                    val fp = Fp()
                    fps[keyFor(fps, mime, i)] = fp
                    fpOf[i] = fp
                    ex.selectTrack(i)
                }
            }
            var buf = ByteBuffer.allocate(2 * 1024 * 1024)
            while (true) {
                val size = ex.sampleSize
                if (size > buf.capacity()) buf = ByteBuffer.allocate((size + size / 2).toInt())
                val n = ex.readSampleData(buf, 0)
                if (n < 0) break
                val fp = fpOf[ex.sampleTrackIndex]
                if (fp != null) {
                    fp.count++
                    fp.bytes += n
                    fp.crc.update(buf.array(), 0, n)
                }
                if (!ex.advance()) break
            }
        } finally {
            ex.release()
        }
        return fps
    }

    private fun mark(ok: Boolean): String = if (ok) "✓" else "✗"

    private fun compare(
        b: Summary,
        a: Summary,
        bf: Map<String, Fp>,
        af: Map<String, Fp>,
        log: List<String>
    ): String {
        val sb = StringBuilder()
        sb.append("== COMPARAISON AVANT → APRÈS ==\n")

        fun cmp(label: String, x: String?, y: String?) {
            sb.append(mark(x == y)).append(' ').append(label).append(" : ")
                .append(x ?: "-").append(" → ").append(y ?: "-").append('\n')
        }

        cmp("Conteneur", b.container, a.container)
        cmp("Résolution", "${b.width} x ${b.height}", "${a.width} x ${a.height}")
        cmp("Codec vidéo", b.vMime, a.vMime)
        val fpsOk = b.fps > 0 && a.fps > 0 && Math.abs(b.fps - a.fps) < 0.05
        sb.append(mark(fpsOk)).append(" Images/s (mesuré) : ")
            .append(String.format(Locale.US, "%.2f → %.2f", b.fps, a.fps)).append('\n')
        cmp("Rotation", b.rotation, a.rotation)
        cmp("Transfert couleur (HDR/SDR)", b.transfer, a.transfer)
        cmp("Codec audio", b.aMime, a.aMime)
        cmp("Audio (Hz)", b.aRate, a.aRate)
        cmp("Audio (canaux)", b.aChannels, a.aChannels)
        val durOk = b.durationMs >= 0 && a.durationMs >= 0 && Math.abs(b.durationMs - a.durationMs) <= 100
        sb.append(mark(durOk)).append(" Durée : ").append(b.durationMs).append(" ms → ")
            .append(a.durationMs).append(" ms\n")
        sb.append("• Taille : ").append(String.format(Locale.US, "%.1f Mo → %.1f Mo", b.size / 1_048_576.0, a.size / 1_048_576.0)).append('\n')

        sb.append("\nDonnées compressées (empreinte CRC32) :\n")
        for ((k, f) in bf) {
            val o = af[k]
            if (o == null) {
                sb.append("✗ ").append(k).append(" : absent de la copie\n")
            } else {
                val same = f.count == o.count && f.bytes == o.bytes && f.crc.value == o.crc.value
                sb.append(mark(same)).append(' ').append(k).append(" : ")
                    .append(if (same) "identique" else "DIFFÉRENT").append(" (")
                    .append(f.count).append(" échantillons, ").append(f.bytes).append(" octets, ")
                    .append(String.format(Locale.US, "%08x", f.crc.value))
                if (!same) {
                    sb.append(" → ").append(o.count).append(" échantillons, ").append(o.bytes)
                        .append(" octets, ").append(String.format(Locale.US, "%08x", o.crc.value))
                }
                sb.append(")\n")
            }
        }

        sb.append("\nMétadonnées :\n")
        sb.append("• Localisation : ").append(b.location ?: "aucune").append(" → ").append(a.location ?: "aucune").append('\n')
        sb.append("• Date de création : ").append(b.creation ?: "aucune").append(" → ").append(a.creation ?: "aucune").append('\n')
        val removed = b.paths.filter { !a.paths.contains(it) }
        val added = a.paths.filter { !b.paths.contains(it) }
        sb.append("• Blocs retirés : ").append(if (removed.isEmpty()) "aucun" else removed.joinToString(", ")).append('\n')
        sb.append("• Blocs ajoutés : ").append(if (added.isEmpty()) "aucun" else added.joinToString(", ")).append('\n')
        if (log.isNotEmpty()) {
            sb.append("\nNeutralisé dans la copie :\n")
            for (l in log) sb.append("• ").append(l).append('\n')
        } else {
            sb.append("\nRien à neutraliser : aucun bloc de métadonnées trouvé.\n")
        }
        return sb.toString()
    }

    // ------------------------------------------------------------------
    // Analyse
    // ------------------------------------------------------------------

    private fun analyze(uri: Uri): Pair<String, Summary> {
        val sb = StringBuilder()
        val s = Summary()
        var locationFound: String? = null

        // 1. Fichier
        var name: String? = null
        var size = -1L
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si = c.getColumnIndex(OpenableColumns.SIZE)
                if (ni >= 0) name = c.getString(ni)
                if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
            }
        }
        s.size = size
        sb.append("== FICHIER ==\n")
        sb.append("Nom : ").append(name ?: "?").append('\n')
        sb.append("Taille : ").append(formatSize(size)).append('\n')

        // 2. Infos générales
        sb.append("\n== INFOS GÉNÉRALES ==\n")
        val mmr = MediaMetadataRetriever()
        try {
            mmr.setDataSource(this, uri)
            fun g(key: Int): String? = mmr.extractMetadata(key)

            s.container = g(MediaMetadataRetriever.METADATA_KEY_MIMETYPE)
            line(sb, "Conteneur", s.container)
            val dur = g(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            if (dur != null) s.durationMs = dur
            line(sb, "Durée", dur?.let { String.format(Locale.US, "%.1f s", it / 1000.0) })
            val br = g(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toLongOrNull()
            line(sb, "Débit global", br?.let { String.format(Locale.US, "%.2f Mb/s", it / 1_000_000.0) })
            s.rotation = g(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)
            line(sb, "Rotation", s.rotation?.let { "$it°" })
            line(sb, "Date (tag)", g(MediaMetadataRetriever.METADATA_KEY_DATE))
            locationFound = g(MediaMetadataRetriever.METADATA_KEY_LOCATION)

            sb.append("\n== TAGS PERSONNELS ==\n")
            line(sb, "Localisation", locationFound ?: "aucune")
            line(sb, "Titre", g(MediaMetadataRetriever.METADATA_KEY_TITLE))
            line(sb, "Auteur", g(MediaMetadataRetriever.METADATA_KEY_AUTHOR))
            line(sb, "Artiste", g(MediaMetadataRetriever.METADATA_KEY_ARTIST))
            line(sb, "Album", g(MediaMetadataRetriever.METADATA_KEY_ALBUM))
            line(sb, "Compositeur", g(MediaMetadataRetriever.METADATA_KEY_COMPOSER))
            line(sb, "Writer", g(MediaMetadataRetriever.METADATA_KEY_WRITER))
        } catch (e: Exception) {
            sb.append("Lecture impossible : ").append(e.message).append('\n')
        } finally {
            mmr.release()
        }

        // 3. Pistes
        sb.append("\n== PISTES ==\n")
        val ex = MediaExtractor()
        try {
            ex.setDataSource(this, uri, null)
            var videoIndex = -1
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: "?"
                sb.append("Piste ").append(i).append(" : ").append(codecName(mime)).append('\n')
                sb.append("  mime : ").append(mime).append('\n')
                if (mime.startsWith("video/")) {
                    if (videoIndex < 0) {
                        videoIndex = i
                        s.vMime = mime
                        s.width = num(f, MediaFormat.KEY_WIDTH)
                        s.height = num(f, MediaFormat.KEY_HEIGHT)
                        s.transfer = num(f, MediaFormat.KEY_COLOR_TRANSFER)?.let { transferName(it) }
                    }
                    val w = num(f, MediaFormat.KEY_WIDTH)
                    val h = num(f, MediaFormat.KEY_HEIGHT)
                    line(sb, "  résolution", if (w != null && h != null) "$w x $h" else null)
                    line(sb, "  fps (tag)", num(f, MediaFormat.KEY_FRAME_RATE))
                    line(sb, "  débit vidéo", num(f, MediaFormat.KEY_BIT_RATE)?.let { "$it b/s" })
                    line(sb, "  rotation", num(f, MediaFormat.KEY_ROTATION))
                    line(sb, "  transfert couleur", num(f, MediaFormat.KEY_COLOR_TRANSFER)?.let { transferName(it) })
                    line(sb, "  standard couleur", num(f, MediaFormat.KEY_COLOR_STANDARD))
                } else if (mime.startsWith("audio/")) {
                    if (s.aMime == null) {
                        s.aMime = mime
                        s.aRate = num(f, MediaFormat.KEY_SAMPLE_RATE)
                        s.aChannels = num(f, MediaFormat.KEY_CHANNEL_COUNT)
                    }
                    line(sb, "  échantillonnage", num(f, MediaFormat.KEY_SAMPLE_RATE)?.let { "$it Hz" })
                    line(sb, "  canaux", num(f, MediaFormat.KEY_CHANNEL_COUNT))
                    line(sb, "  débit audio", num(f, MediaFormat.KEY_BIT_RATE)?.let { "$it b/s" })
                    line(sb, "  langue", if (f.containsKey(MediaFormat.KEY_LANGUAGE)) f.getString(MediaFormat.KEY_LANGUAGE) else null)
                }
            }
            if (videoIndex >= 0) {
                ex.selectTrack(videoIndex)
                var count = 0
                var minT = Long.MAX_VALUE
                var maxT = Long.MIN_VALUE
                while (count < 300) {
                    val t = ex.sampleTime
                    if (t < 0) break
                    if (t < minT) minT = t
                    if (t > maxT) maxT = t
                    count++
                    if (!ex.advance()) break
                }
                if (count > 1 && maxT > minT) {
                    val fps = (count - 1) * 1_000_000.0 / (maxT - minT)
                    s.fps = fps
                    sb.append("fps estimé (").append(count).append(" premières images) : ")
                        .append(String.format(Locale.US, "%.2f", fps)).append('\n')
                }
            }
        } catch (e: Exception) {
            sb.append("Lecture impossible : ").append(e.message).append('\n')
        } finally {
            ex.release()
        }

        // 4. Structure MP4
        sb.append("\n== STRUCTURE DU FICHIER (MP4) ==\n")
        try {
            val pfd = contentResolver.openFileDescriptor(uri, "r")
            if (pfd == null) {
                sb.append("Fichier inaccessible.\n")
            } else {
                ParcelFileDescriptor.AutoCloseInputStream(pfd).use { stream ->
                    val ch = stream.channel
                    val total = ch.size()
                    val scan = Mp4Scan(ch, sb)
                    val stoppedAt = scan.walk(0L, total, 0, "")
                    if (stoppedAt < total) {
                        sb.append("\n⚠ Zone non reconnue à partir de l'octet ")
                            .append(stoppedAt).append(" (")
                            .append(total - stoppedAt).append(" octets)\n")
                    }
                    if (scan.location != null) locationFound = locationFound ?: scan.location
                    s.creation = scan.creation
                    s.paths = scan.paths
                }
            }
        } catch (e: Exception) {
            sb.append("Analyse de structure impossible : ").append(e.message).append('\n')
        }
        s.location = locationFound

        // 5. Résumé
        sb.append("\n== RÉSUMÉ VIE PRIVÉE ==\n")
        sb.append(if (locationFound != null) "⚠ Localisation GPS présente : $locationFound\n" else "✓ Pas de localisation détectée\n")
        sb.append(if (s.creation != null) "⚠ Date de création dans le fichier : ${s.creation}\n" else "✓ Pas de date de création détectée\n")
        sb.append("Cette liste n'est pas exhaustive : voir la structure ci-dessus.\n")

        return Pair(sb.toString(), s)
    }

    // ------------------------------------------------------------------
    // Utilitaires d'affichage
    // ------------------------------------------------------------------

    private fun line(sb: StringBuilder, label: String, value: String?) {
        if (value != null) sb.append(label).append(" : ").append(value).append('\n')
    }

    private fun num(f: MediaFormat, key: String): String? {
        if (!f.containsKey(key)) return null
        return try {
            f.getInteger(key).toString()
        } catch (e: Exception) {
            try {
                f.getFloat(key).toString()
            } catch (e2: Exception) {
                null
            }
        }
    }

    private fun formatSize(bytes: Long): String {
        if (bytes < 0) return "?"
        return String.format(Locale.US, "%.1f Mo (%d octets)", bytes / 1_048_576.0, bytes)
    }

    private fun codecName(mime: String): String = when (mime) {
        "video/avc" -> "Vidéo H.264 (AVC)"
        "video/hevc" -> "Vidéo H.265 (HEVC)"
        "video/x-vnd.on2.vp9" -> "Vidéo VP9"
        "video/av01" -> "Vidéo AV1"
        "audio/mp4a-latm" -> "Audio AAC"
        "audio/opus" -> "Audio Opus"
        "audio/ac3" -> "Audio AC-3"
        else -> mime
    }

    private fun transferName(v: String): String = when (v) {
        "1" -> "linéaire"
        "3" -> "SDR"
        "6" -> "PQ (HDR10)"
        "7" -> "HLG (HDR)"
        else -> v
    }

    // ------------------------------------------------------------------
    // Lecteur de boîtes MP4 (lecture seule)
    // ------------------------------------------------------------------

    private class Mp4Scan(private val ch: FileChannel, private val sb: StringBuilder) {
        var location: String? = null
        var creation: String? = null
        val paths = LinkedHashSet<String>()

        private class Hdr(val type: String, val size: Long, val headerSize: Int)

        private val containers = setOf("moov", "trak", "mdia", "minf", "udta", "edts", "dinf")

        fun walk(start: Long, end: Long, depth: Int, parentPath: String): Long {
            var pos = start
            var count = 0
            val parentType = parentPath.substringAfterLast('/')
            while (pos < end && count < 300) {
                val h = readHeader(pos, end) ?: break
                val path = if (parentPath.isEmpty()) h.type else parentPath + "/" + h.type
                paths.add(path)

                sb.append("  ".repeat(depth)).append(h.type).append(" (").append(h.size).append(" o)")
                when (h.type) {
                    "mvhd" -> readMvhd(pos + h.headerSize)
                    "\u00a9xyz" -> readLocation(pos + h.headerSize, h.size - h.headerSize)
                    "ftyp" -> readBrand(pos + h.headerSize)
                }
                sb.append('\n')

                if (h.type in containers) {
                    walk(pos + h.headerSize, pos + h.size, depth + 1, path)
                } else if (h.type == "meta") {
                    walkMeta(pos + h.headerSize, pos + h.size, depth + 1, path)
                } else if (parentType == "udta" || parentType == "meta") {
                    dump(pos + h.headerSize, h.size - h.headerSize, depth + 1)
                }
                pos += h.size
                count++
            }
            return pos
        }

        /** 'meta' existe avec ou sans l'en-tête version/flags de 4 octets : on essaie les deux. */
        private fun walkMeta(payloadStart: Long, payloadEnd: Long, depth: Int, path: String) {
            for (skip in intArrayOf(4, 0)) {
                val first = readHeader(payloadStart + skip, payloadEnd)
                if (first != null && first.size >= 8 && payloadStart + skip + first.size <= payloadEnd) {
                    walk(payloadStart + skip, payloadEnd, depth, path)
                    return
                }
            }
            dump(payloadStart, payloadEnd - payloadStart, depth)
        }

        private fun readHeader(pos: Long, end: Long): Hdr? {
            if (pos + 8 > end) return null
            val header = ByteBuffer.allocate(16)
            val n = ch.read(header, pos)
            if (n < 8) return null
            header.flip()
            var size = header.int.toLong() and 0xFFFFFFFFL
            val typeBytes = ByteArray(4)
            header.get(typeBytes)
            if (!printable(typeBytes)) return null
            val type = String(typeBytes, Charsets.ISO_8859_1)
            var headerSize = 8
            if (size == 1L) {
                if (n < 16) return null
                size = header.long
                headerSize = 16
            } else if (size == 0L) {
                size = end - pos
            }
            if (size < headerSize) return null
            if (pos + size > end) size = end - pos
            return Hdr(type, size, headerSize)
        }

        private fun printable(b: ByteArray): Boolean {
            for (x in b) {
                val v = x.toInt() and 0xFF
                if (v < 0x20 || v in 0x7F..0xA8) return false
            }
            return true
        }

        private fun dump(pos: Long, len: Long, depth: Int) {
            val n = minOf(len, 96L).toInt()
            if (n <= 0) return
            val b = ByteBuffer.allocate(n)
            val r = ch.read(b, pos)
            if (r <= 0) return
            val arr = b.array()
            val indent = "  ".repeat(depth)
            val hex = StringBuilder()
            for (i in 0 until minOf(r, 16)) hex.append(String.format("%02x ", arr[i].toInt() and 0xFF))
            val txt = StringBuilder()
            for (i in 0 until r) {
                val v = arr[i].toInt() and 0xFF
                txt.append(if (v in 0x20..0x7E) v.toChar() else '.')
            }
            sb.append(indent).append("hex: ").append(hex.toString().trim()).append('\n')
            sb.append(indent).append("txt: ").append(txt).append('\n')
        }

        private fun readBrand(pos: Long) {
            val b = ByteBuffer.allocate(4)
            if (ch.read(b, pos) == 4) {
                sb.append(" → marque ").append(String(b.array(), Charsets.ISO_8859_1))
            }
        }

        private fun readMvhd(pos: Long) {
            val b = ByteBuffer.allocate(12)
            if (ch.read(b, pos) < 12) return
            b.flip()
            val versionFlags = b.int
            val version = (versionFlags shr 24) and 0xFF
            val seconds: Long = if (version == 1) {
                val b8 = ByteBuffer.allocate(8)
                if (ch.read(b8, pos + 4) < 8) return
                b8.flip()
                b8.long
            } else {
                b.int.toLong() and 0xFFFFFFFFL
            }
            if (seconds == 0L) {
                sb.append(" → date de création non définie")
            } else {
                val epochMs = (seconds - 2082844800L) * 1000L
                val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.US)
                fmt.timeZone = TimeZone.getTimeZone("UTC")
                creation = fmt.format(Date(epochMs))
                sb.append(" → créé le ").append(creation)
            }
        }

        private fun readLocation(pos: Long, payload: Long) {
            val len = minOf(payload, 64L).toInt()
            if (len <= 4) return
            val b = ByteBuffer.allocate(len)
            if (ch.read(b, pos) < len) return
            val text = String(b.array(), 4, len - 4, Charsets.ISO_8859_1).trim()
            location = text
            sb.append(" → localisation : ").append(text)
        }
    }

    // ------------------------------------------------------------------
    // Neutralisation des métadonnées (écriture sur la COPIE uniquement)
    // ------------------------------------------------------------------

    private class Mp4Scrub(private val ch: FileChannel, private val log: MutableList<String>) {

        private class Hdr(val type: String, val size: Long, val headerSize: Int)

        fun run() {
            walk(0L, ch.size(), "")
        }

        private fun walk(start: Long, end: Long, path: String) {
            var pos = start
            var count = 0
            while (pos < end && count < 300) {
                val h = readHeader(pos, end) ?: break
                val here = if (path.isEmpty()) h.type else path + "/" + h.type
                val inner = pos + h.headerSize
                val innerEnd = pos + h.size
                when (path) {
                    "" -> when (h.type) {
                        "moov" -> walk(inner, innerEnd, here)
                        "uuid", "meta", "udta", "XMP_" -> makeFree(pos, h, here)
                    }
                    "moov" -> when (h.type) {
                        "udta", "meta", "uuid" -> makeFree(pos, h, here)
                        "mvhd" -> zeroTimes(pos, h, here)
                        "trak" -> walk(inner, innerEnd, here)
                    }
                    "moov/trak" -> when (h.type) {
                        "udta", "meta", "uuid" -> makeFree(pos, h, here)
                        "tkhd" -> zeroTimes(pos, h, here)
                        "mdia" -> walk(inner, innerEnd, here)
                    }
                    "moov/trak/mdia" -> when (h.type) {
                        "mdhd" -> zeroTimes(pos, h, here)
                        "udta", "meta", "uuid" -> makeFree(pos, h, here)
                    }
                    else -> {}
                }
                pos += h.size
                count++
            }
        }

        private fun makeFree(pos: Long, h: Hdr, label: String) {
            writeFully(ByteBuffer.wrap("free".toByteArray(Charsets.ISO_8859_1)), pos + 4)
            var p = pos + h.headerSize
            val end = pos + h.size
            val zeros = ByteArray(65536)
            while (p < end) {
                val n = minOf(zeros.size.toLong(), end - p).toInt()
                writeFully(ByteBuffer.wrap(zeros, 0, n), p)
                p += n
            }
            log.add("$label (${h.size} o) → remplacé par un bloc vide")
        }

        private fun zeroTimes(pos: Long, h: Hdr, label: String) {
            val vb = ByteBuffer.allocate(1)
            if (ch.read(vb, pos + h.headerSize) < 1) return
            val version = vb.get(0).toInt()
            val len = if (version == 1) 16 else 8
            if (h.size < h.headerSize + 4 + len) return
            writeFully(ByteBuffer.wrap(ByteArray(len)), pos + h.headerSize + 4)
            log.add("$label : dates de création/modification remises à zéro")
        }

        private fun writeFully(bb: ByteBuffer, position: Long) {
            var p = position
            while (bb.hasRemaining()) {
                p += ch.write(bb, p)
            }
        }

        private fun readHeader(pos: Long, end: Long): Hdr? {
            if (pos + 8 > end) return null
            val header = ByteBuffer.allocate(16)
            val n = ch.read(header, pos)
            if (n < 8) return null
            header.flip()
            var size = header.int.toLong() and 0xFFFFFFFFL
            val typeBytes = ByteArray(4)
            header.get(typeBytes)
            for (x in typeBytes) {
                val v = x.toInt() and 0xFF
                if (v < 0x20 || v in 0x7F..0xA8) return null
            }
            val type = String(typeBytes, Charsets.ISO_8859_1)
            var headerSize = 8
            if (size == 1L) {
                if (n < 16) return null
                size = header.long
                headerSize = 16
            } else if (size == 0L) {
                size = end - pos
            }
            if (size < headerSize) return null
            if (pos + size > end) size = end - pos
            return Hdr(type, size, headerSize)
        }
    }
}
