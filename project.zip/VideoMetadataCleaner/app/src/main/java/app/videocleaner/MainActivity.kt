package app.videocleaner

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone

class MainActivity : Activity() {

    private lateinit var report: TextView
    private val pickCode = 1001

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(32, 32, 32, 32)
        }

        val title = TextView(this).apply {
            text = "Video Metadata Cleaner"
            textSize = 22f
            gravity = Gravity.CENTER
        }

        val button = Button(this).apply {
            text = "S\u00e9lectionner une vid\u00e9o"
            setOnClickListener { pickVideo() }
        }

        report = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setTextIsSelectable(true)
            text = "Aucune vid\u00e9o s\u00e9lectionn\u00e9e.\n\n" +
                "Choisis une vid\u00e9o pour voir ce qu'elle contient (rien n'est modifi\u00e9 \u00e0 cette \u00e9tape)."
        }

        val scroll = ScrollView(this).apply { addView(report) }

        layout.addView(title)
        layout.addView(button)
        layout.addView(
            scroll,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )
        setContentView(layout)
    }

    private fun pickVideo() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "video/*"
        }
        startActivityForResult(intent, pickCode)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != pickCode || resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        report.text = "Analyse en cours..."
        Thread {
            val text = try {
                analyze(uri)
            } catch (e: Exception) {
                "Erreur pendant l'analyse : ${e.javaClass.simpleName} - ${e.message}"
            }
            runOnUiThread { report.text = text }
        }.start()
    }

    // ------------------------------------------------------------------
    // Analyse
    // ------------------------------------------------------------------

    private fun analyze(uri: Uri): String {
        val sb = StringBuilder()
        var locationFound: String? = null
        var creationDate: String? = null

        // 1. Fichier
        var name: String? = null
        var size = -1L
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val ni = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val si = c.getColumnIndex(OpenableColumns.SIZE)
                if (ni >= 0) name = c.getString(ni)
                if (si >= 0 && !c.isNull(si)) size = c.getLong(si)
            }
        }
        sb.append("== FICHIER ==\n")
        sb.append("Nom : ").append(name ?: "?").append('\n')
        sb.append("Taille : ").append(formatSize(size)).append('\n')

        // 2. Infos g\u00e9n\u00e9rales (MediaMetadataRetriever)
        sb.append("\n== INFOS G\u00c9N\u00c9RALES ==\n")
        val mmr = MediaMetadataRetriever()
        try {
            mmr.setDataSource(this, uri)
            fun g(key: Int): String? = mmr.extractMetadata(key)

            line(sb, "Conteneur", g(MediaMetadataRetriever.METADATA_KEY_MIMETYPE))
            val dur = g(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull()
            line(sb, "Dur\u00e9e", dur?.let { String.format(Locale.US, "%.1f s", it / 1000.0) })
            val br = g(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toLongOrNull()
            line(sb, "D\u00e9bit global", br?.let { String.format(Locale.US, "%.2f Mb/s", it / 1_000_000.0) })
            line(sb, "Rotation", g(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.let { "$it\u00b0" })
            line(sb, "Date (tag)", g(MediaMetadataRetriever.METADATA_KEY_DATE))
            locationFound = g(MediaMetadataRetriever.METADATA_KEY_LOCATION)

            sb.append("\n== TAGS PERSONNELS ==\n")
            line(sb, "Localisation", locationFound ?: "aucune")
            line(sb, "Titre", g(MediaMetadataRetriever.METADATA_KEY_TITLE))
            line(sb, "Auteur", g(MediaMetadataRetriever.METADATA_KEY_AUTHOR))
            line(sb, "Artiste", g(MediaMetadataRetriever.METADATA_KEY_ARTIST))
            line(sb, "Album", g(MediaMetadataRetriever.METADATA_KEY_ALBUM))
            line(sb, "Compositeur", g(MediaMetadataRetriever.METADATA_KEY_COMPOSER))
            line(sb, "Writer", g(MediaMetadataRetriever.METADATA_KEY_WRITER))
        } catch (e: Exception) {
            sb.append("Lecture impossible : ").append(e.message).append('\n')
        } finally {
            mmr.release()
        }

        // 3. Pistes (MediaExtractor)
        sb.append("\n== PISTES ==\n")
        val ex = MediaExtractor()
        try {
            ex.setDataSource(this, uri, null)
            var videoIndex = -1
            for (i in 0 until ex.trackCount) {
                val f = ex.getTrackFormat(i)
                val mime = f.getString(MediaFormat.KEY_MIME) ?: "?"
                sb.append("Piste ").append(i).append(" : ").append(codecName(mime)).append('\n')
                sb.append("  mime : ").append(mime).append('\n')
                if (mime.startsWith("video/")) {
                    if (videoIndex < 0) videoIndex = i
                    val w = num(f, MediaFormat.KEY_WIDTH)
                    val h = num(f, MediaFormat.KEY_HEIGHT)
                    line(sb, "  r\u00e9solution", if (w != null && h != null) "$w x $h" else null)
                    line(sb, "  fps (tag)", num(f, MediaFormat.KEY_FRAME_RATE))
                    line(sb, "  d\u00e9bit vid\u00e9o", num(f, MediaFormat.KEY_BIT_RATE)?.let { "$it b/s" })
                    line(sb, "  rotation", num(f, MediaFormat.KEY_ROTATION))
                    line(sb, "  transfert couleur", num(f, MediaFormat.KEY_COLOR_TRANSFER)?.let { transferName(it) })
                    line(sb, "  standard couleur", num(f, MediaFormat.KEY_COLOR_STANDARD))
                } else if (mime.startsWith("audio/")) {
                    line(sb, "  \u00e9chantillonnage", num(f, MediaFormat.KEY_SAMPLE_RATE)?.let { "$it Hz" })
                    line(sb, "  canaux", num(f, MediaFormat.KEY_CHANNEL_COUNT))
                    line(sb, "  d\u00e9bit audio", num(f, MediaFormat.KEY_BIT_RATE)?.let { "$it b/s" })
                    line(sb, "  langue", if (f.containsKey(MediaFormat.KEY_LANGUAGE)) f.getString(MediaFormat.KEY_LANGUAGE) else null)
                }
            }
            if (videoIndex >= 0) {
                ex.selectTrack(videoIndex)
                var count = 0
                var minT = Long.MAX_VALUE
                var maxT = Long.MIN_VALUE
                while (count < 300) {
                    val t = ex.sampleTime
                    if (t < 0) break
                    if (t < minT) minT = t
                    if (t > maxT) maxT = t
                    count++
                    if (!ex.advance()) break
                }
                if (count > 1 && maxT > minT) {
                    val fps = (count - 1) * 1_000_000.0 / (maxT - minT)
                    sb.append("fps estim\u00e9 (").append(count).append(" premi\u00e8res images) : ")
                        .append(String.format(Locale.US, "%.2f", fps)).append('\n')
                }
            }
        } catch (e: Exception) {
            sb.append("Lecture impossible : ").append(e.message).append('\n')
        } finally {
            ex.release()
        }

        // 4. Structure MP4
        sb.append("\n== STRUCTURE DU FICHIER (MP4) ==\n")
        try {
            val pfd = contentResolver.openFileDescriptor(uri, "r")
            if (pfd == null) {
                sb.append("Fichier inaccessible.\n")
            } else {
                ParcelFileDescriptor.AutoCloseInputStream(pfd).use { stream ->
                    val ch = stream.channel
                    val total = ch.size()
                    val scan = Mp4Scan(ch, sb)
                    val stoppedAt = scan.walk(0L, total, 0)
                    if (stoppedAt < total) {
                        sb.append("\n\u26a0 Zone non reconnue \u00e0 partir de l'octet ")
                            .append(stoppedAt).append(" (")
                            .append(total - stoppedAt).append(" octets)\n")
                    }
                    if (scan.location != null) locationFound = locationFound ?: scan.location
                    creationDate = scan.creation
                }
            }
        } catch (e: Exception) {
            sb.append("Analyse de structure impossible : ").append(e.message).append('\n')
        }

        // 5. R\u00e9sum\u00e9
        sb.append("\n== R\u00c9SUM\u00c9 VIE PRIV\u00c9E ==\n")
        sb.append(if (locationFound != null) "\u26a0 Localisation GPS pr\u00e9sente : $locationFound\n" else "\u2713 Pas de localisation d\u00e9tect\u00e9e\n")
        sb.append(if (creationDate != null) "\u26a0 Date de cr\u00e9ation dans le fichier : $creationDate\n" else "\u2713 Pas de date de cr\u00e9ation d\u00e9tect\u00e9e\n")
        sb.append("Cette liste n'est pas exhaustive : voir la structure ci-dessus.\n")

        return sb.toString()
    }

    // ------------------------------------------------------------------
    // Utilitaires d'affichage
    // ------------------------------------------------------------------

    private fun line(sb: StringBuilder, label: String, value: String?) {
        if (value != null) sb.append(label).append(" : ").append(value).append('\n')
    }

    private fun num(f: MediaFormat, key: String): String? {
        if (!f.containsKey(key)) return null
        return try {
            f.getInteger(key).toString()
        } catch (e: Exception) {
            try {
                f.getFloat(key).toString()
            } catch (e2: Exception) {
                null
            }
        }
    }

    private fun formatSize(bytes: Long): String {
        if (bytes < 0) return "?"
        return String.format(Locale.US, "%.1f Mo (%d octets)", bytes / 1_048_576.0, bytes)
    }

    private fun codecName(mime: String): String = when (mime) {
        "video/avc" -> "Vid\u00e9o H.264 (AVC)"
        "video/hevc" -> "Vid\u00e9o H.265 (HEVC)"
        "video/x-vnd.on2.vp9" -> "Vid\u00e9o VP9"
        "video/av01" -> "Vid\u00e9o AV1"
        "audio/mp4a-latm" -> "Audio AAC"
        "audio/opus" -> "Audio Opus"
        "audio/ac3" -> "Audio AC-3"
        else -> mime
    }

    private fun transferName(v: String): String = when (v) {
        "1" -> "lin\u00e9aire"
        "3" -> "SDR"
        "6" -> "PQ (HDR10)"
        "7" -> "HLG (HDR)"
        else -> v
    }

    // ------------------------------------------------------------------
    // Lecteur de bo\u00eetes MP4 (lecture seule)
    // ------------------------------------------------------------------

    private class Mp4Scan(private val ch: FileChannel, private val sb: StringBuilder) {
        var location: String? = null
        var creation: String? = null

        private val containers = setOf("moov", "trak", "mdia", "minf", "udta", "edts", "dinf")

        /** Parcourt les bo\u00eetes entre start et end. Retourne la position o\u00f9 le parcours s'est arr\u00eat\u00e9. */
        fun walk(start: Long, end: Long, depth: Int): Long {
            var pos = start
            var count = 0
            while (pos < end && count < 300) {
                val header = ByteBuffer.allocate(16)
                val n = ch.read(header, pos)
                if (n < 8) break
                header.flip()
                var size = header.int.toLong() and 0xFFFFFFFFL
                val typeBytes = ByteArray(4)
                header.get(typeBytes)
                if (!printable(typeBytes)) break
                val type = String(typeBytes, Charsets.ISO_8859_1)
                var headerSize = 8
                if (size == 1L) {
                    if (n < 16) break
                    size = header.long
                    headerSize = 16
                } else if (size == 0L) {
                    size = end - pos
                }
                if (size < headerSize) break
                if (pos + size > end) size = end - pos

                sb.append("  ".repeat(depth)).append(type).append(" (").append(size).append(" o)")

                when (type) {
                    "mvhd" -> readMvhd(pos + headerSize)
                    "\u00a9xyz" -> readLocation(pos + headerSize, size - headerSize)
                    "ftyp" -> readBrand(pos + headerSize)
                }
                sb.append('\n')

                if (type in containers) {
                    walk(pos + headerSize, pos + size, depth + 1)
                } else if (type == "meta") {
                    walk(pos + headerSize + 4, pos + size, depth + 1)
                }
                pos += size
                count++
            }
            return pos
        }

        private fun printable(b: ByteArray): Boolean {
            for (x in b) {
                val v = x.toInt() and 0xFF
                if (v < 0x20 || (v in 0x7F..0xA8) || v > 0xFF) return false
            }
            return true
        }

        private fun readBrand(pos: Long) {
            val b = ByteBuffer.allocate(4)
            if (ch.read(b, pos) == 4) {
                sb.append(" \u2192 marque ").append(String(b.array(), Charsets.ISO_8859_1))
            }
        }

        private fun readMvhd(pos: Long) {
            val b = ByteBuffer.allocate(12)
            if (ch.read(b, pos) < 12) return
            b.flip()
            val versionFlags = b.int
            val version = (versionFlags shr 24) and 0xFF
            val seconds: Long = if (version == 1) {
                val b8 = ByteBuffer.allocate(8)
                if (ch.read(b8, pos + 4) < 8) return
                b8.flip()
                b8.long
            } else {
                b.int.toLong() and 0xFFFFFFFFL
            }
            if (seconds == 0L) {
                sb.append(" \u2192 date de cr\u00e9ation non d\u00e9finie")
            } else {
                val epochMs = (seconds - 2082844800L) * 1000L
                val fmt = SimpleDateFormat("yyyy-MM-dd HH:mm:ss 'UTC'", Locale.US)
                fmt.timeZone = TimeZone.getTimeZone("UTC")
                creation = fmt.format(Date(epochMs))
                sb.append(" \u2192 cr\u00e9\u00e9 le ").append(creation)
            }
        }

        private fun readLocation(pos: Long, payload: Long) {
            val len = minOf(payload, 64L).toInt()
            if (len <= 4) return
            val b = ByteBuffer.allocate(len)
            if (ch.read(b, pos) < len) return
            val text = String(b.array(), 4, len - 4, Charsets.ISO_8859_1).trim()
            location = text
            sb.append(" \u2192 localisation : ").append(text)
        }
    }
}
